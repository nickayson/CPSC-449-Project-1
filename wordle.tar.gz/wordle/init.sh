#!/bin/sh

sqlite3 ./wordle.db < ./wordle.sql