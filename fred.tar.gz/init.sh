#!/bin/sh

sqlite3 .wordle.db < ./share/wordle.sql